---
name: "\U0001F917 Support Question"
about: "If you have a question \U0001F4AC, please check out our Discord"

---

--------------^ Click "Preview" for a nicer view!
We primarily use GitHub as an issue & suggestion tracker; for usage and support questions, please check join our Discord: https://discord.gg/mePCs8U

---
